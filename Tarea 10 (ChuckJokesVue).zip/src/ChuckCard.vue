<template>
  <div class="col-lg-4 col-md-6 mb-4">
    <div class="card h-100">
      <img :src="iconUrl" class="card-img-top" alt="Chuck Norris">
      <div class="card-body">
        <p class="card-text">{{ value }}</p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    iconUrl: String,
    value: String
  }
};
</script>

<style scoped>
.chuck-card {
  margin-bottom: 20px;
}
.card {
  border: 1px solid #ddd;
  border-radius: 8px;
  transition: transform 0.3s ease;
}
.card:hover {
  transform: translateY(-5px);
}
.card-img-top {
  border-top-left-radius: 8px;
  border-top-right-radius: 8px;
}
.card-body {
  padding: 20px;
}
.card-text {
  color: #333;
  font-size: 16px;
}
@media (max-width: 768px) {
  .col-lg-4 {
    flex: 0 0 100%;
    max-width: 100%;
  }
}
</style>