<template>
  <div id="app" class="container">
    <h1 class="text-center mb-5">Chuck Norris Jokes</h1>
    <div class="row">
      <chuck-card v-for="(joke, index) in chuck" :key="index" :icon-url="joke.icon_url" :value="joke.value"></chuck-card>
    </div>
  </div>
</template>

<script>
import ChuckCard from './components/ChuckCard.vue';

export default {
  components: {
    'chuck-card': ChuckCard
  },
  data() {
    return {
      chuck: [
        { "icon_url": "https://assets.chucknorris.host/img/avatar/chuck-norris.png", "value": "Chuck Norris can skydive into outer space." },
        { "icon_url": "https://assets.chucknorris.host/img/avatar/chuck-norris.png", "value": "The chief export of Chuck Norris is pain." },
        { "icon_url": "https://assets.chucknorris.host/img/avatar/chuck-norris.png", "value": "Chuck Norris doesn't read books. He stares them down until he gets the information he wants." },
        { "icon_url": "https://assets.chucknorris.host/img/avatar/chuck-norris.png", "value": "Time waits for no man. Unless that man is Chuck Norris." },
        { "icon_url": "https://assets.chucknorris.host/img/avatar/chuck-norris.png", "value": "If you spell Chuck Norris in Scrabble, you win. Forever." }
      ]
    };
  }
};
</script>


<style>
#app {
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  text-align: center;
  background-color: #f5f5f5;
  padding: 20px;
}

h1 {
  color: #333;
  margin-bottom: 30px;
  font-size: 28px;
}

.joke-list {
  list-style-type: none;
  padding: 0;
}

.joke-item {
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  padding: 20px;
  margin-bottom: 20px;
  transition: transform 0.3s ease;
}

.joke-item:hover {
  transform: translateY(-5px);
}
</style>