<template>
  <div id="app">
    <h1>Chuck Norris Jokes</h1>
    <ul>
      <li v-for="(joke, index) in chuck" :key="index">{{ joke.value }}</li>
    </ul>
  </div>
</template>

<script>
export default {
  data() {
    return {
      chuck: [
        { "value": "Chuck Norris can skydive into outer space." },
        { "value": "The chief export of Chuck Norris is pain." },
        { "value": "Chuck Norris doesn't read books. He stares them down until he gets the information he wants." },
        { "value": "Time waits for no man. Unless that man is Chuck Norris." },
        { "value": "If you spell Chuck Norris in Scrabble, you win. Forever." }
      ]
    };
  }
};
</script>

<style>
#app {
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  text-align: center;
  background-color: #f5f5f5;
  padding: 20px;
}

h1 {
  color: #333;
  margin-bottom: 30px;
  font-size: 28px;
}

.joke-list {
  list-style-type: none;
  padding: 0;
}

.joke-item {
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  padding: 20px;
  margin-bottom: 20px;
  transition: transform 0.3s ease;
}

.joke-item:hover {
  transform: translateY(-5px);
}
</style>